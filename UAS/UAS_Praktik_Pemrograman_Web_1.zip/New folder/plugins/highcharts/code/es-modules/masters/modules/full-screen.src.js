/**
 * @license Highstock JS v9.0.1 (2021-02-15)
 * @module highcharts/modules/full-screen
 * @requires highcharts
 *
 * Advanced Highstock tools
 *
 * (c) 2010-2021 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/FullScreen.js';
